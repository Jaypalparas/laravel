<?php

use App\Http\Controllers\slugController;
use Illuminate\Support\Facades\Route;



Route::get('/', function () {
    return view('welcome');
})->name('welcome');

Route::post('store',[slugController::class,'store'])->name('store');

route::get('show',[slugController::class,'show'])->name('show');

Route::delete('destroy/{id}',[slugController::class,'destroy'])->name('destroy');
// when do using resource then instead of delete() use post method
Route::get('uploadFile',[slugController::class,'uploadFile'])->name('uploadFile');
Route::post('uplodedFiles',[slugController::class,'uplodedFiles'])->name('uplodedFiles');

// Route::get('/showFiles', function () {
//     return view('showFiles');
// });

Route::get('slugData',[slugController::class,'slugData'])->name('slugData');
Route::get('showdata',[slugController::class,'showdata'])->name('showdata');
