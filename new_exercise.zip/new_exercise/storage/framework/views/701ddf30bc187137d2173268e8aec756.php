<!doctype html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>slug and soft delete</title>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.7.0/jquery.min.js"></script>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.1/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-4bw+/aepP/YC94hEpVNVgiZdgIC5+VKNBQNGCHeKRQN+PtmoHDEXuppvnDJzQIu9" crossorigin="anonymous">
    <style>
        table.table.table-dark,
        .alert.alert-warning.alert-dismissible.fade.show {
            width: 60%;
            margin: 0 auto;
        }

        div#mybtn {
            display: flex;
            width: 60%;
            margin: 0 auto;
            border-radius: 0px;
            justify-content: space-between;
        }
    </style>
</head>

<body>
    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
        <a href="<?php echo e(route('slugData')); ?>">back</a>
    </button>
    <table class="table table-dark">
        <?php if(session('status')): ?>
            <div class="alert alert-warning alert-dismissible fade show" id="mybtn" role="alert">
                <?php echo e(session('status')); ?>

                <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
        <?php endif; ?>


        <thead>
            <tr>
                <th scope="col">ID</th>
                <th scope="col">name</th>
                <th scope="col">slug</th>
                <th scope="col">action</th>

            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $table; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td scope="row"><?php echo e($data->id); ?></th>
                    <td scope="row"><?php echo e($data->name); ?></th>
                    <td scope="row"><?php echo e($data->slug); ?></th>
                       <td>
                        <form action="<?php echo e(route('destroy',$data->id)); ?>" method="post"> 
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('DELETE'); ?>
                        <button class="btn btn-danger" type="submit">delete</button>
                        </form>
                       </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
        <script>
            $(document).ready(function() { 
                $('#mybtn').click(function() { //for hide success message...
                    $(this).hide();
                });
            });
            
        </script>
    </table>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.1/dist/js/bootstrap.bundle.min.js"
        integrity="sha384-HwwvtgBNo3bZJJLYd8oVXjrBZt8cqVSpeBNS5n7C8IVInixGAoxmnlMuBnhbgrkm" crossorigin="anonymous">
    </script>
</body>

</html>
<?php /**PATH C:\xampp23\htdocs\Laravel\new_exercise\resources\views/show.blade.php ENDPATH**/ ?>