<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>slug demo</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-4bw+/aepP/YC94hEpVNVgiZdgIC5+VKNBQNGCHeKRQN+PtmoHDEXuppvnDJzQIu9" crossorigin="anonymous">

</head>
  <body>
   
   
    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
      <a href="<?php echo e(route('slugData')); ?>"> slug task</a>
  </button>
    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
      <a href="<?php echo e(route('uploadFile')); ?>"> file upload task</a>
  </button>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.1/dist/js/bootstrap.bundle.min.js" integrity="sha384-HwwvtgBNo3bZJJLYd8oVXjrBZt8cqVSpeBNS5n7C8IVInixGAoxmnlMuBnhbgrkm" crossorigin="anonymous"></script>
  </body>
</html>

<?php /**PATH C:\xampp23\htdocs\Laravel\new_exercise\resources\views/welcome.blade.php ENDPATH**/ ?>