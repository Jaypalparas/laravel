<?php

namespace App\Models;
use Illuminate\Support\Str;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;//for soft delete

class slug extends Model
{
    use HasFactory,SoftDeletes;

    protected $fillable = ['name','slug'];


    protected function setNameAttribute($value ){ //mutators(for set data ) only for set...
        $this->attributes['name']=ucwords($value);
    }
    public function getNameAttribute($value)//accessor(for get data ) only for get...
    {
        return strtoupper($value);
        // return   Str::of($value)->mask('*', 3); // using this you can hide or apply symbol like jay****
    }
   

    //this is second way of creating mutators&accessor you can apply both set and get
        // protected function name(): Attribute 
    // {
        
    //     return Attribute::make(
    //         get: fn (string $value) => Str::of($value)->prepend('mr.  '),
    //         set: fn (string $value) => Str::lower($value),
    //     );
    // }
}
