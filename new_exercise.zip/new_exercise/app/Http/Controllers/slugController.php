<?php

namespace App\Http\Controllers;

use App\Models\slug;
use Attribute;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Redirect;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Str; //for slug




class slugController extends Controller
{
    public function store(Request $request)
    {

        $validatedData = $request->input();

        $validatedData['slug'] = Str::slug($request->input('name'));
        //    $validatedData['slug']= str_slug($request->input('name'));
        slug::create($validatedData);
        // return redirect('/');
        return Redirect('show')->with('status', 'successfully inserted');
    }

    public function show()
    {
        $table = slug::all();
        // $table = slug::withTrashed()->get();  //to get also deleted data ... 
        // $table = slug::onlyTrashed()->get();  //to get only deleted data ... 

        // var_dump($table);
        return view('show', compact('table'));
    }
    public function destroy($id)
    {
        $mydata = slug::findOrFail($id);
        $mydata->Delete(); //soft delete....
        // $mydata->forceDelete(); // delete permanent

        return redirect('show');
    }
    public function uploadFile()
    {
        return view('uploadFile');
    }
    public function slugData()
    {
        return view('slugData');
    }

    public function uplodedFiles(Request $request)
    {
        // $fileName=time()."-paras.".$request->file('name')->getClientOriginalExtension();//for get/store real image name
        //  $request->file('name')->storeAs('uploads',$fileName);//create folder in public folder named upload...

        $imageName = time() . "-paras." . request()->name->getClientOriginalExtension();
        request()->name->move(public_path('images'), $imageName);
        $users = DB::table('file_upload')->insert(['name' => $imageName]);
        return redirect('showdata');
    }
    public function showdata()
    {
        $data = DB::table('file_upload')->get();

        return view('showFiles', compact('data'));

    }

}




// extra 
// for restore deleted data
// public function show()
// {        
//     $table = slug::all(); 

//     // var_dump($table);
//     return view('show', compact('table'));
// }
// public function destroy($id){
//     // $mydata=slug::findOrFail($id);
//     $mydata = slug::withTrashed()->find($id);
//     $mydata->restore();
//     // $mydata->Delete(); //soft delete....
//     // $mydata->forceDelete(); // delete permanent
//     // $mydata->restore();
//     return redirect('show');
// }