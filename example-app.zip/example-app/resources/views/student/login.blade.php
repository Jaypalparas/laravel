<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Login</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: sans-serif;
        }

        body {
            background-color: #131313;
            display: flex;
            justify-content: center;
            align-items: center;
        }

        h1 {
            color: #ffffff;
            text-align: center;
        }

        .container {
            width: 680px;
        }

        .entryarea {
            position: relative;
            height: 80px;
            line-height: 80px;
        }

        .myInput {
            position: absolute;
            width: 100%;
            outline: none;
            font-size: 2.2em;
            padding: 0 30px;
            line-height: 80px;
            border-radius: 10px;
            border: 2px solid #f0ffff;
            background: transparent;
            z-index: 1111;
            color: #D2FF00;
            margin-bottom: 30px;
        }

        .labelline {
            position: absolute;
            font-size: 1.6em;
            color: #f0ffff;
            padding: 0 25px;
            margin: 0 24px;
            background-color: #131313;
            transition: 0.2s ease;
        }

        .myInput:focus, .myInput:valid {
            color: #D2FF00;
            border: 4px solid #D2FF00;
        }

        .myInput:focus + .labelline,
        .myInput:valid + .labelline {
            color: #D2FF00;
            height: 30px;
            line-height: 30px;
            transform: translate(-15px, -16px) scale(0.88);
            z-index: 1111;
        }

        button {
            padding: 10px 20px;
            margin: 0 20px;
            background-color: #52FF00;
            border: none;
            border-radius: 4px;
            font-size: 20px;
            font-weight: bold;
        }

        button:hover {
            border: 2px solid #52FF00;
            background: transparent;
            color: #52FF00;
        }

        #resetButton {
            background-color: #ff002b;
            color: #ffffff;
        }

        #resetButton:hover {
            border: 2px solid #ff002b;
            background: transparent;
            color: #ff002b;
        }

        #buttons {
            display: flex;
            justify-content: center;
        }
        .error-message{
            color: red;
            font-size: 16px;
                }
    </style>
</head>
<body>
    <div class="container">
        @if(session('error'))
    <div class="error-message">
        {{ session('error')}}
    </div>
@endif
        <div class="entryarea">
            <h1>Login Form</h1>
           
          <form action="{{route('checklog')}}" method="post">
            @csrf
            <input type="text" id="email" value=" " class="myInput" required name="email">
            <div class="labelline">Email</div><br><br>
            <input type="password" id="password" required class="myInput" name="password">
            <div class="labelline">Password</div> <br><br>
            <div id="buttons">
                <button type="reset" id="resetButton" onclick="clearValue()">Reset</button>
                <button type="submit" id="submitButton">Submit</button>
            </div>
          </form>
        </div>
    </div>
    <script>
        function clearValue() {
            document.getElementById("email").value = "";
            document.getElementById("password").value = "";
        }
    </script>
</body>
</html>
