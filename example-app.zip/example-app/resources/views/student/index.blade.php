<!doctype html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Bootstrap demo</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-rbsA2VBKQhggwzxH7pPCaAqO46MgnOM80zW1RWuH61DGLwZJEdK2Kadq2F9CUG65" crossorigin="anonymous">
</head>
<body>
<style>
   .table {
    outline: 1px solid #b79797;
    width: 80%;
    margin: 3% auto;
   
}
div.mydiv {
    margin-top: 2%;
}
td.cmb-btn {
    justify-content: center;
    display: flex;
}
th.action-btn {
    text-align: center;
}
    button.my-btn {
        margin-right: 5px;
    width: 60px;
    margin-bottom: 5px;
}
.my-btn a{
    text-decoration: none;
    color: white;
}
a.ad-btn {
    text-align: center;
    margin: 0 auto;
    text-decoration: none;
    color: white;
    background: blue;
    padding: 10px;
    border-radius: 5px;
    display: block;
    width: 100px;
}
</style>
<div class="container ">
    @if(session('message'))
    <div class="error-message">
        {{ session('message')}}
    </div>
    @endif
    <table class="table table-striped table-hover">
        <div class="mydiv">
    
            <a class="ad-btn" href="{{ route('welcome') }}" class="btn btn-primary ">logout</a>
        </div>
            <thead>
                <tr>
                    <th scope="col">Id</th>
                    <th scope="col">Name</th>
                    <th scope="col">Email</th>
                    {{-- <th scope="col">Password</th> --}}
                    <th class="action-btn" scope="col">Action</th>
                    
                </tr>
            </thead>
            <tbody>
               
               
                    @foreach ($table as $sdata)
                        <tr>
                            <td>
                                {{$sdata->id}}
                            </td>
                            <td>
                                {{$sdata->name}}
                            </td>
                            <td>
                                {{$sdata->email}}
                            </td>
                            {{-- <td>
                                {{$sdata->password}}
                            </td> --}}
                            <td class="cmb-btn">
                                <button type="button" class="btn btn-info my-btn"><a href="{{route('student.show',$sdata->id)}}">view</a></button>
                                <button type="button" class="btn btn-success my-btn"><a href="{{route('student.edit',$sdata->id)}}">Edit</a></button>
                              <form action="{{route('student.destroy',$sdata->id)}}" method="POST"> 
                                @csrf
                                @method('DELETE')
                            <button class="btn btn-danger" type="submit">delete</button>
                            </form>
                            </td>
                        </tr>
                    @endforeach
            </tbody>
        </table>    
         
</div>
    
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js"
        integrity="sha384-kenU1KFdBIe4zVF0s0G1M5b4hcpxyD9F7jL+jjXkk+Q2h455rYXK/7HAuoJl+0I4" crossorigin="anonymous">
    </script>
</body>

</html>
