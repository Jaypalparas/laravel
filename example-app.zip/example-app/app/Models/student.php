<?php
// app/Models/Student.php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Student extends Model
{
    use HasFactory;
    
    protected $table = 'students';
    protected $fillable = ['name', 'email', 'password'];
    
    public static function storeOrUpdateStudent($data)
    {
        $condition = ['id' => $data['id']];
        unset($data['_token']);
        Student::updateOrCreate($condition, $data);
    }

    public static function deleteUser($id)
    {
        $student = self::findOrFail($id);
        $student->delete();
    }
}
