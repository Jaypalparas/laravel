<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\student;
use App\Http\Requests\myRequest;//for validation
use Illuminate\Support\Facades\Hash; //for password enctypt in database

class StudentController extends Controller
{

    public function index()
    {
        $table = student::all(); //student is the model name and all is the method for only fetching all data (or- for paginate write below)

        return view('student.index', compact('table'));
        // (compact('table')) passes the $table variable to the view.
        //  The compact() function creates an associative array 

    }


    public function create()
    {
        return view('student.create');
    }

    public function store(myRequest $request)
    {
        $postData = $request->input();
        $postData['password'] = Hash::make($postData['password']); //for password enctypt in database 
        Student::storeOrUpdateStudent($postData);
        return redirect('student');
    }

    // ... Other methods ...

    public function destroy($id)
    {
        Student::deleteUser($id);
        return redirect('student');
    }
    public function show($id) //view user
    {
        $table = student::findOrFail($id);

        return view('student.showUser', compact('table'));
    }


    public function edit($id)
    {
        $table = student::findOrFail($id); //using this function it find all the record of one row from table
        return view('student.create', compact('table'));
    }
    public function mylogin()
    {
        return view('student.login');
    }
 

    public function checklog(Request $request)
    {

        $email = $request->input('email');
        $password = $request->input('password');
        $data = student::where('email', $email)->first();//retrive first record or one row with password

        if ($data && Hash::check($password, $data->password)) { //hash method match encrypt password
            return redirect('student')->with('message', 'Logged in successfully!');
        } else {
            return redirect('login')->with('error', 'Invalid email or password.');
        }
       
    }


    public function myregister()
    {
        return view('student.create');
    }

}