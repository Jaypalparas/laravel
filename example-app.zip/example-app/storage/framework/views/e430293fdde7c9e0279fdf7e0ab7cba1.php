
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<style>
  body {
    font-family: Arial, sans-serif;
    margin: 0;
    padding: 0;
    background-color: #f2f2f2;
    display: flex;
    justify-content: center;
    align-items: center;
    min-height: 100vh;
  }

  .data-container {
    background-color: #fff;
    border-radius: 10px;
    padding: 20px;
    box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
    width: 300px;
  }

  .data-field {
    margin-bottom: 10px;
  }

  .data-label {
    font-weight: bold;
  }

  .data-value {
    color: #666;
  }
</style>

<title>User Data Display</title>
</head>
<body>
  <div class="data-container">
    <div class="data-field">
      <span class="data-label">Id:</span>
      <span class="data-value"><?php echo e($table->id); ?></span>
    </div>
    <div class="data-field">
      <span class="data-label">Name:</span>
      <span class="data-value"><?php echo e($table->name); ?></span>
    </div>
    <div class="data-field">
      <span class="data-label">Email:</span>
      <span class="data-value"> <?php echo e($table->email); ?></span>
    </div>
    
  </div>
</body>
</html>
<?php /**PATH C:\xampp23\htdocs\Laravel\example-app\resources\views/student/showUser.blade.php ENDPATH**/ ?>