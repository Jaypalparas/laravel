<?php

use App\Http\Controllers\StudentController;
use Illuminate\Support\Facades\Route;


Route::get('/', function () {
    return view('welcome');
})->name('welcome');

Route::resource('student', StudentController::class);


Route::get('login',[ StudentController::class,'mylogin'])->name('login');
Route::post('checklog',[ StudentController::class,'checklog'])->name('checklog');

Route::get('register',[ StudentController::class,'myregister'])->name('register');


// Route::get('register', function () {
//     return view('student.create');
// })->name('register');