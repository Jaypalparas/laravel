
 -------------------student controller------------------------------------
 <?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use  App\Models\student;
use App\Http\Requests\myRequest;
class StudentController extends Controller
{
   
    public function index()
    {
        $table=student::all(); //student is the model name and all is the method for only fetching all data (or- for paginate write below)
        $table=student::simplePaginate(3); //instead of above ocd
        return view('student.index',compact('table'));
        // (compact('table')) passes the $table variable to the view.
        //  The compact() function creates an associative array 
        
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        return view('student.create');
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(myRequest $request)//request store the post array then pass to $post variable
    {
        $post=$request->input();
        unset($post['_token']); //unset the token generated from @csrf
        $condition = ['id'=> $post['id']]; //if data in id then call update, if data is not then post and call create
        student::updateOrCreate($condition,$post);//here create is used to insert data
        return redirect('student');//go to index page available in model
        // return back()->with('success', 'User created successfully.'); for back to same page
    }

    /**
     * Display the specified resource.
     */
    public function show($id)//view user
    {
        $table=student::findOrFail($id); 
        
        return view('student.showUser',compact('table'));
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit( $id)
    {
        $table = student::findOrFail($id);//using this function it find all the record of one row from table
      return view('student.create',compact('table'));
    }

    /**
     * Update is used when only 
     */

    // public function update(Request $request, $id)
    // {
    //     //$request store the updated data and $id get the id 
    //     $table=student::findOrFail($id);//from $id to store data in table
    //     $post=$request->input();//here $request data are stored to $post
       
    //     $table->update($post);//here post data will be update in table or old data will be replaced...
    //     return redirect('student');
    // }


    public function destroy($id)
    {
        $table=student::findOrFail($id);
        $table->delete();
        return redirect('student');
    }
}
---------------student model-----------------
<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class student extends Model
{
    use HasFactory;
    protected $table='students';
    protected $fillable= ['name','email','password'];//used for fill the data or insert data

    
}
